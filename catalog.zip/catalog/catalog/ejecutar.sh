source venv/bin/activate
export FLASK_APP=crud flask run